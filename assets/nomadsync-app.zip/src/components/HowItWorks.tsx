import React from 'react';
import {
  UserPlusIcon,
  ClipboardListIcon,
  FileCheckIcon,
  CheckCircleIcon } from
'lucide-react';
export function HowItWorks() {
  return (
    <section
      className="py-24 bg-navy-900 text-cream-50 relative overflow-hidden"
      id="how-it-works">
      
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div
          className="absolute top-0 left-0 w-full h-full"
          style={{
            backgroundImage: 'radial-gradient(#FDFBF7 1px, transparent 1px)',
            backgroundSize: '40px 40px'
          }}>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <span className="text-terracotta-500 font-bold tracking-wider text-sm uppercase mb-3 block">
            The Process
          </span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-cream-50">
            How It Works
          </h2>
        </div>

        <div className="relative">
          {/* Connecting Line (Desktop) */}
          <div className="hidden md:block absolute top-12 left-0 w-full h-px bg-cream-50/20"></div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8">
            {/* Step 1 */}
            <div className="relative flex flex-col items-center text-center group">
              <div className="w-24 h-24 rounded-full bg-navy-800 border-2 border-terracotta-500 flex items-center justify-center mb-8 relative z-10 group-hover:bg-terracotta-600 transition-colors duration-500">
                <UserPlusIcon className="h-10 w-10 text-cream-50" />
              </div>
              <h3 className="text-2xl font-serif font-bold mb-4">Sign Up</h3>
              <p className="text-cream-200/80 leading-relaxed max-w-xs">
                Create your account and choose the services you need help with.
              </p>
            </div>

            {/* Step 2 */}
            <div className="relative flex flex-col items-center text-center group">
              <div className="w-24 h-24 rounded-full bg-navy-800 border-2 border-terracotta-500 flex items-center justify-center mb-8 relative z-10 group-hover:bg-terracotta-600 transition-colors duration-500">
                <ClipboardListIcon className="h-10 w-10 text-cream-50" />
              </div>
              <h3 className="text-2xl font-serif font-bold mb-4">
                Tell Us What You Need
              </h3>
              <p className="text-cream-200/80 leading-relaxed max-w-xs">
                Upload your basic details. Our system generates your
                personalized checklist.
              </p>
            </div>

            {/* Step 3 */}
            <div className="relative flex flex-col items-center text-center group">
              <div className="w-24 h-24 rounded-full bg-navy-800 border-2 border-terracotta-500 flex items-center justify-center mb-8 relative z-10 group-hover:bg-terracotta-600 transition-colors duration-500">
                <FileCheckIcon className="h-10 w-10 text-cream-50" />
              </div>
              <h3 className="text-2xl font-serif font-bold mb-4">
                We Handle It
              </h3>
              <p className="text-cream-200/80 leading-relaxed max-w-xs">
                We prepare your forms, pay the taxes, and book your
                appointments.
              </p>
            </div>

            {/* Step 4 */}
            <div className="relative flex flex-col items-center text-center group">
              <div className="w-24 h-24 rounded-full bg-navy-800 border-2 border-terracotta-500 flex items-center justify-center mb-8 relative z-10 group-hover:bg-terracotta-600 transition-colors duration-500">
                <CheckCircleIcon className="h-10 w-10 text-cream-50" />
              </div>
              <h3 className="text-2xl font-serif font-bold mb-4">
                You're All Set
              </h3>
              <p className="text-cream-200/80 leading-relaxed max-w-xs">
                Attend your appointment with our prepared package and get your
                documents.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>);

}