import React from 'react';
import { CheckIcon, XIcon } from 'lucide-react';
import { Button } from './ui/Button';
export function PricingSection() {
  return (
    <section className="py-24 bg-cream-100" id="pricing">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy-900 mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-navy-800/70 max-w-2xl mx-auto">
            Choose how you want to handle your paperwork. Do it yourself with
            our guides, or let our experts handle the bureaucracy for you.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto items-start">
          {/* Free Tier */}
          <div className="bg-white p-8 md:p-10 rounded-sm border border-navy-900/10 shadow-sm relative">
            <h3 className="text-2xl font-serif font-bold text-navy-900 mb-2">
              Self-Service
            </h3>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-4xl font-bold text-navy-900">€0</span>
              <span className="text-navy-800/60 font-medium">/forever</span>
            </div>
            <p className="text-navy-800/70 mb-8 min-h-[3rem]">
              Perfect for students who are comfortable navigating Spanish
              administration on their own.
            </p>

            <Button variant="outline" className="w-full mb-8">
              Get Started Free
            </Button>

            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm">
                  Step-by-step PDF guides
                </span>
              </li>
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm">
                  Official document checklists
                </span>
              </li>
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm">
                  Access to community forum
                </span>
              </li>
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm">
                  Basic email templates
                </span>
              </li>
              <li className="flex items-start gap-3 text-navy-900/40">
                <XIcon className="h-5 w-5 shrink-0 mt-0.5" />
                <span className="text-sm">Human expert support</span>
              </li>
              <li className="flex items-start gap-3 text-navy-900/40">
                <XIcon className="h-5 w-5 shrink-0 mt-0.5" />
                <span className="text-sm">Appointment booking service</span>
              </li>
            </ul>
          </div>

          {/* Premium Tier */}
          <div className="bg-white p-8 md:p-10 rounded-sm border-2 border-terracotta-600 shadow-xl relative transform md:-translate-y-4">
            <div className="absolute top-0 right-0 bg-terracotta-600 text-white text-xs font-bold px-3 py-1 uppercase tracking-wider rounded-bl-sm">
              Most Popular
            </div>

            <h3 className="text-2xl font-serif font-bold text-navy-900 mb-2">
              Expert Guided
            </h3>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-4xl font-bold text-navy-900">€15</span>
              <span className="text-navy-800/60 font-medium">/process</span>
            </div>
            <p className="text-navy-800/70 mb-8 min-h-[3rem]">
              We handle the stress. A dedicated expert manages your application
              from start to finish.
            </p>

            <Button variant="secondary" className="w-full mb-8">
              Get Expert Help
            </Button>

            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm font-medium">
                  Everything in Self-Service
                </span>
              </li>
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm">
                  Dedicated human expert
                </span>
              </li>
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm">
                  Document review & preparation
                </span>
              </li>
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm">
                  We book the appointments for you
                </span>
              </li>
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm">
                  Real-time chat support
                </span>
              </li>
              <li className="flex items-start gap-3">
                <CheckIcon className="h-5 w-5 text-terracotta-600 shrink-0 mt-0.5" />
                <span className="text-navy-900/80 text-sm">
                  Money-back guarantee
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-sm text-navy-800/60 font-medium">
            Trusted by 2,000+ international students in Spain
          </p>
        </div>
      </div>
    </section>);

}