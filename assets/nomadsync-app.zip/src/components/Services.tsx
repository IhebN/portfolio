import React from 'react';
import {
  FileTextIcon,
  HomeIcon,
  HeartPulseIcon,
  ShieldCheckIcon,
  ArrowRightIcon,
  ClockIcon } from
'lucide-react';
interface Service {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  timeline: string;
  features: string[];
}
const services: Service[] = [
{
  id: 'nie',
  title: 'NIE Application',
  description:
  'The Foreigner Identity Number is essential for everything from opening a bank account to getting a phone contract.',
  icon: FileTextIcon,
  timeline: '2-4 Weeks',
  features: [
  'Form EX-15 preparation',
  'Appointment booking',
  'Tax payment guide']

},
{
  id: 'empadronamiento',
  title: 'Empadronamiento',
  description:
  'Register your address with the local city hall. Mandatory for getting your TIE and accessing public services.',
  icon: HomeIcon,
  timeline: '1-3 Days',
  features: [
  'Document checklist',
  'City hall registration',
  'Certificate download']

},
{
  id: 'healthcare',
  title: 'Public Healthcare',
  description:
  'Register for the Spanish National Health System (CatSalut in Catalonia) to get your health card.',
  icon: HeartPulseIcon,
  timeline: '1 Week',
  features: ['Eligibility check', 'CAP assignment', 'Card application']
},
{
  id: 'social-security',
  title: 'Social Security',
  description:
  'Required if you plan to do an internship or work part-time during your studies in Spain.',
  icon: ShieldCheckIcon,
  timeline: '24 Hours',
  features: [
  'TA.1 form filing',
  'Digital certificate help',
  'Instant number generation']

}];

export function Services() {
  return (
    <section
      className="py-24 bg-cream-50 border-t border-navy-900/5"
      id="services">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="text-terracotta-600 font-bold tracking-wider text-sm uppercase mb-3 block">
            Our Services
          </span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy-900 mb-6">
            Everything You Need to Get Settled
          </h2>
          <p className="text-lg text-navy-800/70 leading-relaxed">
            Navigating Spanish bureaucracy can be overwhelming. We break down
            complex legal processes into simple, manageable steps so you can
            focus on your studies.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) =>
          <div
            key={service.id}
            className="group bg-white border border-navy-900/10 p-8 rounded-sm hover:shadow-lg hover:border-terracotta-600/30 transition-all duration-300 flex flex-col">
            
              <div className="flex justify-between items-start mb-6">
                <div className="p-3 bg-cream-100 rounded-sm text-terracotta-600 group-hover:bg-terracotta-600 group-hover:text-cream-50 transition-colors duration-300">
                  <service.icon className="h-8 w-8" />
                </div>
                <div className="flex items-center gap-1 text-xs font-bold text-navy-900/60 bg-navy-50 px-2 py-1 rounded-sm uppercase tracking-wide">
                  <ClockIcon className="h-3 w-3" />
                  {service.timeline}
                </div>
              </div>

              <h3 className="text-2xl font-serif font-bold text-navy-900 mb-3 group-hover:text-terracotta-600 transition-colors">
                {service.title}
              </h3>

              <p className="text-navy-800/70 mb-6 font-sans leading-relaxed">
                {service.description}
              </p>

              <ul className="space-y-2 mb-8 flex-1">
                {service.features.map((feature, i) =>
              <li
                key={i}
                className="flex items-center text-sm text-navy-800/80">
                
                    <span className="w-1.5 h-1.5 bg-terracotta-500 rounded-full mr-2"></span>
                    {feature}
                  </li>
              )}
              </ul>

              <div className="mt-auto pt-6 border-t border-navy-900/5 flex items-center text-navy-900 font-medium group-hover:text-terracotta-600 transition-colors cursor-pointer">
                Learn more
                <ArrowRightIcon className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          )}
        </div>
      </div>
    </section>);

}