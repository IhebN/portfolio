import React from 'react';
import {
  GlobeIcon,
  TwitterIcon,
  InstagramIcon,
  LinkedinIcon } from
'lucide-react';
export function Footer() {
  return (
    <footer className="bg-cream-100 border-t border-navy-900/10 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="space-y-6">
            <a href="/" className="flex items-center gap-2 group">
              <div className="bg-navy-900 text-cream-50 p-1.5 rounded-sm">
                <GlobeIcon className="h-5 w-5" />
              </div>
              <span className="font-serif text-xl font-bold text-navy-900">
                NomadSync<span className="text-terracotta-600">.</span>
              </span>
            </a>
            <p className="text-navy-800/70 text-sm leading-relaxed">
              Making student relocation to Spain simple, transparent, and
              stress-free.
            </p>
            <div className="flex gap-4">
              <a
                href="#"
                className="text-navy-900 hover:text-terracotta-600 transition-colors">
                
                <TwitterIcon className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-navy-900 hover:text-terracotta-600 transition-colors">
                
                <InstagramIcon className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-navy-900 hover:text-terracotta-600 transition-colors">
                
                <LinkedinIcon className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links Column 1 */}
          <div>
            <h4 className="font-serif font-bold text-navy-900 mb-6">
              Services
            </h4>
            <ul className="space-y-3 text-sm text-navy-800/70">
              <li>
                <a
                  href="#"
                  className="hover:text-terracotta-600 transition-colors">
                  
                  NIE Application
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-terracotta-600 transition-colors">
                  
                  Empadronamiento
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-terracotta-600 transition-colors">
                  
                  Healthcare Registration
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-terracotta-600 transition-colors">
                  
                  Social Security
                </a>
              </li>
            </ul>
          </div>

          {/* Links Column 2 */}
          <div>
            <h4 className="font-serif font-bold text-navy-900 mb-6">
              Resources
            </h4>
            <ul className="space-y-3 text-sm text-navy-800/70">
              <li>
                <a
                  href="#"
                  className="hover:text-terracotta-600 transition-colors">
                  
                  Student Guide
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-terracotta-600 transition-colors">
                  
                  Document Checklist
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-terracotta-600 transition-colors">
                  
                  FAQ
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="hover:text-terracotta-600 transition-colors">
                  
                  Blog
                </a>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-serif font-bold text-navy-900 mb-6">
              Stay Updated
            </h4>
            <p className="text-sm text-navy-800/70 mb-4">
              Get the latest updates on Spanish immigration laws and student
              tips.
            </p>
            <form className="flex gap-2">
              <input
                type="email"
                placeholder="Email address"
                className="flex-1 bg-white border border-navy-900/10 px-3 py-2 text-sm focus:outline-none focus:border-terracotta-600" />
              
              <button className="bg-navy-900 text-cream-50 px-4 py-2 text-sm font-medium hover:bg-terracotta-600 transition-colors">
                Join
              </button>
            </form>
          </div>
        </div>

        <div className="border-t border-navy-900/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-navy-800/50">
          <p>&copy; 2024 NomadSync. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-navy-900">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-navy-900">
              Terms of Service
            </a>
            <a href="#" className="hover:text-navy-900">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>);

}