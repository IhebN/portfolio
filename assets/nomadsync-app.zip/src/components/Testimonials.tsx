import React from 'react';
import { QuoteIcon } from 'lucide-react';
export function Testimonials() {
  return (
    <section className="py-24 bg-cream-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Image Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4 mt-8">
              <img
                src="https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?q=80&w=1887&auto=format&fit=crop"
                alt="Student portrait"
                className="w-full aspect-[3/4] object-cover rounded-sm grayscale hover:grayscale-0 transition-all duration-500" />
              
              <img
                src="https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?q=80&w=1949&auto=format&fit=crop"
                alt="Student group"
                className="w-full aspect-square object-cover rounded-sm grayscale hover:grayscale-0 transition-all duration-500" />
              
            </div>
            <div className="space-y-4">
              <img
                src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=2070&auto=format&fit=crop"
                alt="Campus life"
                className="w-full aspect-square object-cover rounded-sm grayscale hover:grayscale-0 transition-all duration-500" />
              
              <img
                src="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?q=80&w=1887&auto=format&fit=crop"
                alt="Student portrait"
                className="w-full aspect-[3/4] object-cover rounded-sm grayscale hover:grayscale-0 transition-all duration-500" />
              
            </div>
          </div>

          {/* Editorial Quote */}
          <div className="relative">
            <QuoteIcon className="h-24 w-24 text-terracotta-600/20 absolute -top-12 -left-8 -z-10" />

            <figure className="space-y-8">
              <blockquote className="text-3xl md:text-4xl font-serif font-medium text-navy-900 leading-tight">
                "I was terrified of the NIE process. NomadSync handled
                everything—the forms, the appointment, even the tax payment. I
                just showed up and got my card."
              </blockquote>

              <figcaption className="flex items-center gap-4 border-l-4 border-terracotta-600 pl-6">
                <div>
                  <div className="font-bold text-navy-900 text-lg">
                    Marcus Chen
                  </div>
                  <div className="text-navy-800/60">
                    Master's Student at ESADE Business School
                  </div>
                </div>
              </figcaption>
            </figure>

            <div className="mt-12 grid grid-cols-2 gap-8 border-t border-navy-900/10 pt-8">
              <div>
                <div className="text-4xl font-serif font-bold text-terracotta-600 mb-1">
                  2,000+
                </div>
                <div className="text-sm text-navy-900 font-medium">
                  Students Helped
                </div>
              </div>
              <div>
                <div className="text-4xl font-serif font-bold text-terracotta-600 mb-1">
                  4.9/5
                </div>
                <div className="text-sm text-navy-900 font-medium">
                  Average Rating
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>);

}