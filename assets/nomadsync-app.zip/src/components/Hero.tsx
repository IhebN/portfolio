import React from 'react';
import { Button } from './ui/Button';
export function Hero() {
  return (
    <section className="relative w-full overflow-hidden bg-cream-50 pt-16 pb-24 lg:pt-32 lg:pb-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="space-y-8 animate-fade-in-up">
            <div className="inline-block border-b-2 border-terracotta-600 pb-1">
              <span className="text-terracotta-600 font-bold tracking-wider text-sm uppercase">
                Student Relocation Experts
              </span>
            </div>

            <h1 className="text-5xl lg:text-7xl font-serif font-bold text-navy-900 leading-[1.1]">
              Settle Into Spain, <br />
              <span className="italic text-terracotta-600">Stress-Free</span>
            </h1>

            <p className="text-lg text-navy-800/80 max-w-md leading-relaxed font-sans">
              We handle your NIE, empadronamiento, and healthcare registration
              so you can focus on what matters: your experience abroad.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button variant="primary" size="lg" withArrow>
                Start My Process
              </Button>
              <Button variant="outline" size="lg">
                See Pricing
              </Button>
            </div>

            <div className="pt-8 flex items-center gap-8 text-sm text-navy-900/60 font-medium">
              <div className="flex items-center gap-2">
                <span className="block w-2 h-2 rounded-full bg-terracotta-600"></span>
                2,000+ Students Helped
              </div>
              <div className="flex items-center gap-2">
                <span className="block w-2 h-2 rounded-full bg-terracotta-600"></span>
                48h Avg. Turnaround
              </div>
            </div>
          </div>

          {/* Visual Content - Abstract Map Composition */}
          <div className="relative lg:h-[600px] w-full flex items-center justify-center lg:justify-end">
            {/* Decorative circle background */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-cream-100 rounded-full blur-3xl -z-10"></div>

            {/* Main Image Composition */}
            <div className="relative w-full max-w-lg aspect-[4/5] md:aspect-square lg:aspect-[4/5]">
              {/* Image 1 - Main */}
              <div className="absolute inset-0 bg-navy-900 rounded-sm overflow-hidden shadow-2xl transform transition-transform hover:scale-[1.02] duration-700">
                <img
                  src="https://images.unsplash.com/photo-1543783207-ec64e4d95325?q=80&w=2070&auto=format&fit=crop"
                  alt="Madrid architecture"
                  className="w-full h-full object-cover opacity-90 hover:opacity-100 transition-opacity duration-700" />
                
                <div className="absolute inset-0 bg-navy-900/20 mix-blend-multiply"></div>
              </div>

              {/* Image 2 - Overlay Top Right */}
              <div className="absolute -top-12 -right-12 w-48 h-64 bg-terracotta-600 rounded-sm overflow-hidden shadow-xl border-4 border-cream-50 hidden md:block transform hover:-translate-y-2 transition-transform duration-500">
                <img
                  src="https://images.unsplash.com/photo-1558642084-fd07fae5282e?q=80&w=1936&auto=format&fit=crop"
                  alt="Barcelona street"
                  className="w-full h-full object-cover" />
                
              </div>

              {/* Image 3 - Overlay Bottom Left */}
              <div className="absolute -bottom-12 -left-12 w-56 h-40 bg-white rounded-sm overflow-hidden shadow-xl border-4 border-cream-50 hidden md:block transform hover:translate-y-2 transition-transform duration-500">
                <img
                  src="https://images.unsplash.com/photo-1554224155-6726b3ff858f?q=80&w=2026&auto=format&fit=crop"
                  alt="Paperwork and documents"
                  className="w-full h-full object-cover" />
                
              </div>

              {/* Decorative Elements */}
              <div className="absolute -z-10 -bottom-8 -right-8 w-64 h-64 border border-navy-900/10 rounded-full"></div>
              <div className="absolute -z-10 top-12 -left-16 w-32 h-32 border-2 border-terracotta-600/20 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </section>);

}