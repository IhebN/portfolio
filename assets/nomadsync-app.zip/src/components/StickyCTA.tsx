import React, { useEffect, useState } from 'react';
import { Button } from './ui/Button';
export function StickyCTA() {
  const [isVisible, setIsVisible] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      // Show after scrolling past 500px (roughly past hero)
      if (window.scrollY > 500) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  return (
    <div
      className={`fixed bottom-0 left-0 w-full bg-navy-900 text-cream-50 py-4 px-6 z-40 transform transition-transform duration-500 shadow-[0_-4px_20px_rgba(0,0,0,0.1)] ${isVisible ? 'translate-y-0' : 'translate-y-full'}`}>
      
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="hidden sm:block">
          <p className="font-serif text-lg font-medium">
            Need help with your paperwork?
          </p>
          <p className="text-sm text-cream-200/70">
            Get expert guidance for your NIE, empadronamiento, and more.
          </p>
        </div>
        <div className="flex items-center gap-4 w-full sm:w-auto">
          <Button
            variant="secondary"
            className="w-full sm:w-auto whitespace-nowrap">
            
            Talk to an Expert
          </Button>
        </div>
      </div>
    </div>);

}