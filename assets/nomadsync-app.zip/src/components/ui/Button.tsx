import React from 'react';
import { ArrowRightIcon } from 'lucide-react';
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'text';
  size?: 'sm' | 'md' | 'lg';
  withArrow?: boolean;
}
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  withArrow = false,
  className = '',
  ...props
}: ButtonProps) {
  const baseStyles =
  'inline-flex items-center justify-center transition-all duration-300 font-medium tracking-wide focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-navy-900 disabled:opacity-50 disabled:cursor-not-allowed';
  const variants = {
    primary:
    'bg-navy-900 text-cream-50 hover:bg-navy-800 border border-transparent shadow-sm',
    secondary:
    'bg-terracotta-600 text-white hover:bg-terracotta-700 border border-transparent shadow-sm',
    outline:
    'bg-transparent border-2 border-navy-900 text-navy-900 hover:bg-navy-900 hover:text-cream-50',
    text: 'bg-transparent text-navy-900 hover:text-terracotta-600 underline-offset-4 hover:underline p-0'
  };
  const sizes = {
    sm: 'text-sm px-4 py-2',
    md: 'text-base px-6 py-3',
    lg: 'text-lg px-8 py-4'
  };
  // Text variant doesn't need padding if it's just a link style
  const sizeStyles = variant === 'text' ? '' : sizes[size];
  return (
    <button
      className={`${baseStyles} ${variants[variant]} ${sizeStyles} ${className}`}
      {...props}>
      
      {children}
      {withArrow && <ArrowRightIcon className="ml-2 h-4 w-4" />}
    </button>);

}