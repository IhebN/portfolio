import React from 'react';
import { MenuIcon, SearchIcon, GlobeIcon } from 'lucide-react';
import { Button } from './ui/Button';
export function Navbar() {
  return (
    <nav className="sticky top-0 z-50 w-full bg-cream-50/90 backdrop-blur-md border-b border-navy-900/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex items-center">
            <a href="/" className="flex items-center gap-2 group">
              <div className="bg-navy-900 text-cream-50 p-1.5 rounded-sm group-hover:bg-terracotta-600 transition-colors">
                <GlobeIcon className="h-6 w-6" />
              </div>
              <span className="font-serif text-2xl font-bold text-navy-900 tracking-tight">
                NomadSync<span className="text-terracotta-600">.</span>
              </span>
            </a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a
              href="#services"
              className="text-navy-900 hover:text-terracotta-600 font-medium transition-colors">
              
              Services
            </a>
            <a
              href="#how-it-works"
              className="text-navy-900 hover:text-terracotta-600 font-medium transition-colors">
              
              How It Works
            </a>
            <a
              href="#pricing"
              className="text-navy-900 hover:text-terracotta-600 font-medium transition-colors">
              
              Pricing
            </a>
            <a
              href="#"
              className="text-navy-900 hover:text-terracotta-600 font-medium transition-colors">
              
              About
            </a>
          </div>

          {/* Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <a
              href="#"
              className="text-sm font-medium text-navy-900 hover:text-terracotta-600">
              
              Log in
            </a>
            <Button variant="primary" size="sm">
              Get Started
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button className="text-navy-900 hover:text-terracotta-600 p-2">
              <MenuIcon className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </nav>);

}